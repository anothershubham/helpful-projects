# node-role-based-authorization-api

Node.js Role Based Authorization API

For documentation and instructions check out http://jasonwatmore.com/post/2018/11/28/nodejs-role-based-authorization-tutorial-with-example-api